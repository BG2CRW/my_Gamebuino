# Metalog
A Logic simulator for the gamebuino
