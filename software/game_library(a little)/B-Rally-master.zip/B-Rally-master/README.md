# B-Rally
little racing game for Gamebuino

Screenshot: <img src="Bitmaps/slide_race.gif"></img>

uses ADXL345 if available.

<a href="http://gamebuino.com/forum/viewtopic.php?f=17&t=3407">Gamebuino Forum thread</a>
