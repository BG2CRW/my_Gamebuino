  _____                      _           _                ___   ___  _  _   ___
 / ____|                    | |         (_)              |__ \ / _ \| || | / _ \
| |  __  __ _ _ __ ___   ___| |__  _   _ _ _ __   ___       ) | | | | || || (_) |
| | |_ |/ _` | '_ ` _ \ / _ \ '_ \| | | | | '_ \ / _ \     / /| | | |__   _> _ <
| |__| | (_| | | | | | |  __/ |_) | |_| | | | | | (_) |   / /_| |_| |  | || (_) |
 \_____|\__,_|_| |_| |_|\___|_.__/ \__,_|_|_| |_|\___/   |____|\___/   |_| \___/
                                by Josiah Winslow

#############
#Description#
#############


A Gamebuino port of the incredibly addicting game 2048 by Gabriele Cirulli
that took the Internet by storm in 2014.


##########
#Controls
#
##########

* ARROW KEYS: Slide tiles in the direction you press

* A: Save your game

* B: Reset your game

* B+A (hold B and press A): Reset your save

* C: Quit to the title screen (automatically saves your game)


##############


#Installation
#
##############

Copy file /Bin/GB2048.hex to your microSD card.