# Maze for Gamebuino

[Gamebuino](http://gamebuino.com) implementation of a simple 2D maze game.

![Screenshot](src/images/sim.gif?raw=true)

[Try it out](http://games.aoneill.com/play.html?hex=https%3A%2F%2Fraw.githubusercontent.com%2Faoneill01%2Fgamebuino-maze%2Fmaster%2Fdist%2FMAZE.HEX) in an emulator.

# Playing the game

Use the Gamebuino arrow keys to navigate from the top left to the bottom right of the maze. There are 5 progressively larger randomly generated mazes.
